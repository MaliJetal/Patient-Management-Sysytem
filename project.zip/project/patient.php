<!DOCTYPE html>
<html>
<head>
	<title>Patient info</title>
	<link href="https://fonts.googleapis.com/css?family=Anton|Lobster|Slabo+27px" rel="stylesheet">
	<style type="text/css">
		.container{
				font-family: 'Slabo 27px', serif;
				font-family: 'Anton', sans-serif;
				color:#00695C;
				margin:50px;
		}
		#but{
			margin-top: 25px;
		}

	</style>
</head>
<?php 
     include_once 'header.php'
     ?>
<body>
	<div class="container">
		<form action="#">
  				<div class="row">
   				    <div class="col">
   				    	<label for="pid">PATIENT-ID</label>
     				   <input type="text" class="form-control" placeholder="Patient-ID">
     				   <label for="opdid">OPD-ID</label>
     				   <input type="text" class="form-control" placeholder="OPD-ID">
     				   <label for="name">NAME</label>
     				   <input type="text" class="form-control" placeholder="NAME">
						  <label for="sex">SEX</label>
						  <label class="form-control" >M
						  <input type="radio" checked="checked" name="radio">
						  <span class="checkmark"></span>
						  </label>
						  <label class="form-control">F
						  <input type="radio" name="radio">
						  <span class="checkmark"></span>
						  </label>
						  <label class="form-control">Others
						  <input type="radio"  name="radio">
						  <span class="checkmark"></span>
						  </label>
     				   <label for="age">AGE</label>
     				   <input type="number" class="form-control" placeholder="AGE" maxlength="3">
   				   </div>
   				 <div class="col">
   				 	<label for="addr">ADDRESS</label>
						     				 <input type="text" class="form-control" placeholder="ADDRESS" maxlength="50">
     				 <label for="contact">CONTACT</label>
     				 <input type="number" class="form-control" placeholder="Contact" maxlength="10">
     				 <label for="date">DATE</label>
     				 <input type="date" class="form-control" placeholder="yy/mm/dd">
     				 <!-- dropdown -->
     				 <label for="dept">DEPARTMENT</label>
     				 	 <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
   							 <option selected>Choose...</option>
   							 <option value="1">One</option>
    						 <option value="2">Two</option>
    						 <option value="3">Three</option>
 						 </select>
 					<label for="doc">DOCTOR</label>
     				  <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
   							 <option selected>Choose...</option>
   							 <option value="1">One</option>
   							 <option value="2">Two</option>
   							 <option value="3">Three</option>
 					 </select>
   				 </div>
 				 </div>
 				 <div id="but">
 				 	<a href="#" class="btn btn-primary btn-lg active btn-block" role="button" aria-pressed="true">SAVE</a>
					<a href="#" class="btn btn-secondary btn-lg active btn-block" role="button" aria-pressed="true">CANCEL</a>
				</div>
		</form>


	</div>
   			
	
</body>
</html>