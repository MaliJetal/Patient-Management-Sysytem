<!DOCTYPE html>
<html>
<head>
	<title>PMS</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<style type="text/css">
	 body{
      background: url("pmss.jpg")no-repeat center center fixed;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
    a{
  color:#fff;
}
.con{
      float:right;
      color:#1A237E;
      font-family: 'Faster One', cursive;
    }
  </style>
</head>
<body>
  <!-- LOGO-->
          <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
            <a class="navbar-brand" href="#">
              <img src="we-care.png" width="60" height="60" alt="">
            </a>
             <div class="con"><img src="contact.png"  width="60" height="60" alt=""><b>9158112399</b></div>
          </nav>
    <!-- navbar class -->
            <nav class="navbar navbar-light" style="background-color: #9bc5ef;">
               <a class="navbar-brand" href="#">Navbar</a>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                 <span class="navbar-toggler-icon"></span>
               </button>
               <div class="collapse navbar-collapse" id="navbarNav">
                  <ul class="navbar-nav">
                    <li class="nav-item active">
                      <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="#">Features</a>
                   </li>
                   <li class="nav-item">
                      <a class="nav-link" href="#">Pricing</a>
                   </li>
                   <li class="nav-item">
                      <a class="nav-link disabled" href="#">Disabled</a>
                    </li>
                 </ul>
              </div>
            </nav>
  <script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>