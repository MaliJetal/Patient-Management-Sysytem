    <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">        
<title>View Users</title>  
    </head>  
    <style>  
        .login-panel {  
            margin-top: 150px;  
        }  
        .table {  
            margin-top: 50px;  
      
        }  
		
    a{
  color:#fff;
}
.con{
      float:right;
      color:#1A237E;
      font-family: 'Faster One', cursive;
    }
      
    </style>  
      
    <body>  <!-- LOGO-->
          <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
            <a class="navbar-brand" href="#">
              <img src="we-care.png" width="60" height="60" alt="">
            </a>
			<h1>Patient Management System</h1>
             <div class="con"><img src="contact.png"  width="60" height="60" alt=""><b>9158112399</b></div>
          </nav>
    <!-- navbar class -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
  
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Home.php">Home </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Admin Logged In <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Details.php">Add Patient Details</a>
      </li>
     
    </ul>
  </div>
</nav>
      
    <div class="table-scrol">  
        <h1 align="center">All the Patients</h1>  
      
    <div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->  
      
      
        <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">  
            <thead>  
      
            <tr>  
      
                <th>Patient Name</th>  
                <th>Gender</th>  
                <th>Age</th>  
                <th>Contact</th>  
				<th>Doctor's ID</th> 
                <th>Delete Patient</th>  
            </tr>  
            </thead>  
      
            <?php  
            include("Db_conection.php");  
            $view_users_query="select * from patient";//select query for viewing users.  
            $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.  
      
            while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
            {  
                $user_name=$row[1];  
                $gender=$row[2];  
                $age=$row[3];  
                $contact=$row[4];
				$doctor_id=$row[5];
				$date_of_appointment=$row[6];
				$date_of_next_appointment=$row[7];
				$date_of_discharge=$row[8];
				$user_id=$row[0];
				
      
      
      
            ?>  
      
            <tr>  
    <!--here showing results in the table -->  
                <td><?php echo $user_name;  ?></td>  
                <td><?php echo $gender;  ?></td>  
                <td><?php echo $age;  ?></td>  
                <td><?php echo $contact;  ?></td>  
				<td><?php echo $doctor_id;  ?></td>
                <td><a href="delete.php?del=<?php echo $user_id ?>"><button class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
            </tr>  
      
            <?php } ?>  
      
        </table>  
            </div>  
    </div>  
	<input type="button" style="float:right" class="btn btn-primary btn-lg" value="Logout" onclick=" logout()">

<script>
function logout()
{
     location.href = "Logout.php";
} 
</script>
      
      
      
    </body>  
      
    </html>  
