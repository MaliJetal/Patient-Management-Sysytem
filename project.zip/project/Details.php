    <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">    
        <title>Save Details</title> 

          <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">

    </head>  
    <style>  
       
		body{
      background: url("pmss.jpg")no-repeat center center fixed;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
    a{
  color:#fff;
}
.con{
      float:right;
      color:#1A237E;
      font-family: 'Faster One', cursive;
    }
      
    </style>  
    <body>  
	<!-- LOGO-->
          <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
            <a class="navbar-brand" href="#">
              <img src="we-care.png" width="60" height="60" alt="">
            </a>
			<h1>Patient Management System</h1>
             <div class="con"><img src="contact.png"  width="60" height="60" alt=""><b>9158112399</b></div>
          </nav>
    <!-- navbar class -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
  
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Home.php">Home </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="Admin_login.php">Admin Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Medications.php">Medications</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="View_doctors.php">Expert Doctors</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="About.php">About Us</a>
      </li>
     
    </ul>
  </div>
</nav>
      
    <div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->  
        <div class="row"><!-- row class is used for grid system in Bootstrap-->  
            <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->  
                <div class="login-panel panel panel-success">  
                    <div class="panel-heading">  
                        <h3 class="panel-title">Enter Patient Details</h3>  
                    </div>  
                    <div class="panel-body">  
                        <form role="form" method="post" action="Details.php">  
                            <fieldset>  
                                <div class="form-group row">
									<label  class="col-sm-2 col-form-label">Patient Name:</label>
									<div class="col-sm-10">
										<input type="text" class="form-control"  name="name" required>
									</div>
								</div>
								<div class="form-group row">
									<label  class="col-sm-2 col-form-label">Gender:</label>
									<div class="col-sm-10">
										<input type="text" class="form-control"  name="gender" required>
									</div>
								</div>
								<div class="form-group row">
									<label  class="col-sm-2 col-form-label">Age:</label>
									<div class="col-sm-10">
										<input type="text" class="form-control"  name="age" required>
									</div>
								</div>
								<div class="form-group row">
									<label  class="col-sm-2 col-form-label">Contact:</label>
									<div class="col-sm-10">
										<input type="text" class="form-control"  name="contact" required>
									</div>
								</div>
								<div class="form-group row">
									<label  class="col-sm-2 col-form-label">Doctor's id:</label>
									<div class="col-sm-10">
										<input type="text" class="form-control"  name="D_Id" required>
									</div>
								</div>
      
      
                                  
      <input class="btn btn-lg btn-success btn-block" type="submit" value="Save Details" name="details" >
                            </fieldset>  
							
                        </form>  
                          
                    </div>  
                </div>  
            </div>  
        </div> 
    </div>  
	<input type="button" style="float:right" class="btn btn-primary btn-lg" value="Logout" onclick=" logout()">

<script>
function logout()
{
     location.href = "Logout.php";
} 
</script>
      


      <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
      <!--Just to make our placeholder images work. Don't actually copy the next line! -->
       <script src="../../assets/js/vendor/holder.js"></script>
    <!--IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
     <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.js"><\/script>')</script>
   <script src="js/jquery.js"></script>
   
   
    </body>  
      
    </html>  
      
    <?php  
      
    include("Db_conection.php");//make connection here  
    if(isset($_POST['details']))  
    {  
        $name=$_POST['name'];//here getting result from the post array after submitting the form.  
        $gender=$_POST['gender'];//same  
        $age=$_POST['age'];//same  
      $contact=$_POST['contact'];
	  $d_id=$_POST['D_Id'];
	  
      
        
    //insert the user into the database.  
        $insert_user="insert into patient (PName,Gender,Age,Contact,D_Id,Date_of_appointment) VALUES ('$name','$gender','$age','$contact','$d_id',NOW())";
		$result = @mysqli_query($dbcon,$insert_user);
        if($result)  
        {  
            echo"<script>window.open('Details.php','_self')</script>";  
        }
      
      
      
    }  
      
    ?>  
