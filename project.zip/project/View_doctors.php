    <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">        
<title>View Users</title>  
    </head>  
    <style>  
        .login-panel {  
            margin-top: 150px;  
        }  
        .table {  
            margin-top: 50px;  
      
        }  
		
    a{
  color:#fff;
}
.con{
      float:right;
      color:#1A237E;
      font-family: 'Faster One', cursive;
    }
      
    </style>  
      
    <body>  <!-- LOGO-->
          <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
            <a class="navbar-brand" href="#">
              <img src="we-care.png" width="60" height="60" alt="">
            </a>
			<h1>Patient Management System</h1>
             <div class="con"><img src="contact.png"  width="60" height="60" alt=""><b>9158112399</b></div>
          </nav>
    <!-- navbar class -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
  
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Home.php">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Medications.php">Medications</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="View_doctors.php">Expert Doctors</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="About.php">About Us</a><li class="nav-item active">
        
      </li>
	   <li class="nav-item">
        <a class="nav-link" href="Admin_login.php">Login</a><li class="nav-item active">
        
      </li>
      
     
    </ul>
  </div>
</nav>
      
    <div class="table-scrol">  
        <h1 align="center">All the Doctors</h1>  
      
    <div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->  
      
      
        <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">  
            <thead>  
      
            <tr>  
      
                <th>Doctor ID</th>  
                <th>Doctor's Name</th>  
				<th>Specialization</th> 
                <th>Years of Experience</th>                   
				<th>Email ID</th> 
				<th>Contact No.</th> 

            </tr>  
            </thead>  
      
            <?php  
            include("Db_conection.php");  
            $view_users_query="select * from doctor";//select query for viewing users.  
            $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.  
      
            while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
            {  
				$d_id=$row[0];
                $d_name=$row[1];  
                $specializtion=$row[2];  
                $experience=$row[3];  
                $email=$row[4];
				$contact=$row[5];
				
				
      
      
      
            ?>  
      
            <tr>  
    <!--here showing results in the table -->  
                <td><?php echo $d_id  ?></td>  
                <td><?php echo $d_name;  ?></td>  
                <td><?php echo $specializtion;  ?></td>  
                <td><?php echo $experience;  ?></td>  
				<td><?php echo $email;  ?></td>
			    <td><?php echo $contact;  ?></td>
            </tr>  
      
            <?php } ?>  
      
        </table>  
            </div>  
    </div>      
    </body>  
      
    </html>  
