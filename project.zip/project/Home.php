<html>  
    <head lang="en">  
        <meta charset="UTF-8">  
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">        
<title>View Users</title>  
    </head>  
    <style>  
        .login-panel {  
            margin-top: 150px;  
        }  
        .table {  
            margin-top: 50px;  
      
        }  body{
      background: url("pmss.jpg")no-repeat center center fixed;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
		
		
    a{
  color:#fff;
}
.con{
      float:right;
      color:#1A237E;
      font-family: 'Faster One', cursive;
    }
	.footer-col{
		margin-top: 150px; 
	}
      
    </style>  
      
    <body>  <!-- LOGO-->
          <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
            <a class="navbar-brand" href="#">
              <img src="we-care.png" width="60" height="60" alt="">
            </a>
			<h1>Patient Management System</h1>
             <div class="con"><img src="contact.png"  width="60" height="60" alt=""><b>9158112399</b></div>
          </nav>
    <!-- navbar class -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
  
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Medications.php">Medications</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="View_doctors.php">Expert Doctors</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="About.php">About Us</a><li class="nav-item active">
        
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="Admin_login.php">Login</a>
      </li>
      
     
    </ul>
  </div>
  </nav>
  <div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">PMS</h1>
    <p>A description of the interaction, from intake to discharge, between the patient and the health care team. It includes communication, empathy, examination, evaluation, diagnosis, prognosis, and intervention. The last element, intervention (or treatment), depends on the others.</p>
  </div>
</div>


</body>  
      
    </html> 