<?php  
/** 
 * Created by PhpStorm. 
 * User: Ehtesham Mehmood 
 * Date: 11/21/2014 
 * Time: 1:13 AM 
 */

$user='root';
$pass='';
$db='hospital';
$conn=new mysqli('localhost',$user,$pass,$db) or die("Unable to connect");
//$dbcon=mysqli_connect("localhost","root","");  
//mysqli_select_db($dbcon,"hospital");  


?>