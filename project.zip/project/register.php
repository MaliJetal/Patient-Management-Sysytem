  <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
  <link rel="icon" href="favicon.ico">

    <title>Registration Page</title>

  
    <script src="js/bootstrap.js"></script>
      <script src="js/jquery.js"></script>
    <!-- Bootstrap core CSS -->
  
    <link href="css/custom.css" rel="stylesheet">
      <link href="css/bootstrap.css" rel="stylesheet">

    <!--IE10 viewport hack for Surface/desktop Windows 8 bug   -->
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!--Just for debugging purposes. Don't actually copy these 2 lines! -->
   <!-- [if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]-->
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <!--[endif]-->

    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
    </head>  
    <style>  
        .login-panel {  
		margin-top: 150px;  }
		body{
      background: url("images/pmss.jpg")no-repeat center center fixed;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
    a{
  color:#fff;
}
.con{
      float:right;
      color:#1A237E;
      font-family: 'Faster One', cursive;
    }
      
    </style>  
      
    <body>  
     

 
     <div class="navbar-wrapper">
      <div class="container">

        <nav class="navbar navbar-inverse navbar-static-top" >
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="#">Project name</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
              <div style="display: inline-block">
              <ul class="nav navbar-nav">

                <li class="" ><a href="home.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="#contact">Contact</a></li>
                <li class="dropdown">

                  <a href="#" >Details<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Patient</a></li>
                    <li><a href="#">Medicine</a></li>
                    <li><a href="#">O.P.D</a></li>
                    <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Admin</li>
                    <li><a href="#">Billing</a></li>
                   
                  </ul>
                </li>
              </ul>
            </div>
          </div>
          </div>
        </nav>
      </div>
    </div>

 <!-- LOGO-->
          <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
            <a class="navbar-brand" href="#">
              <img src="images/we-care.png" width="60" height="60" alt="">
            </a>
      
           
          </nav>


    <div class="container">  
        <div class="row">  
            <div class="col-md-4 col-md-offset-4">  
                <div class="login-panel panel panel-success">  
                    <div class="panel-heading">  
                        <h3 class="form-signin-heading">Sign Up</h3>  
                    </div>  
                    <div class="panel-body">  
                        <form role="form" method="post" action="register.php" class="form-signin">  
                            <fieldset>  
                               <div class="form-group"  >  
                                    <input class="form-control" placeholder="Username" name="admin_uname" type="name" autofocus required>  
                                </div>  

                                <div class="form-group"  >  
                                    <input class="form-control" placeholder="Name" name="admin_name" type="email" autofocus required>  
                                </div>  
                                <div class="form-group">  
                                    <input class="form-control" placeholder="Password" name="admin_pass" type="password" value="">  
                                </div>  
                                <div class="form-group"  >  
                                    <input class="form-control" placeholder="Mobile Number" name="admin_no" type="Number" autofocus required>  
                                </div>
      
                                
                                <input class="btn btn-lg btn-success btn-block" type="submit" value="Sign Up" name="admin_login" >
                                
                                <a href="admin_login.php"><h4 style="color: blue;text-align: center">Login in</h4></a>
      
      
                            </fieldset>  
                        </form>  
                    </div>  
                </div>  
            </div>  
        </div> 
		
    </div>  

      <!-- FOOTER -->
      <footer>
          <div ><img src="images/contact.png"  width="100" height="100" alt=""><b>9158112399</b></div>
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2016 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </footer>

    </div><!-- /.container -->

      
        <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery.js"><\/script>')</script>
    
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="js/bootstrap.js"></script>
    </body>  
      
    </html>  
      
    <?php  
    /** 
     * Created by PhpStorm. 
     * User: Ehtesham Mehmood 
     * Date: 11/24/2014 
     * Time: 3:26 AM 
     */  
    include("Db_conection.php");  

     
    if(mysqli_connect_error())
     {
          die('Connect error('.mysqli_connect_errno().')'.mysqli_connect_error());
    }
   if (isset($_POST['admin_login']))//this will tell us what to do if some data has been post through form with button.  
    {  
        $admin_uname=$_POST['admin_uname'];  
        $admin_name=$_POST['admin_name'];  
        $admin_pass=$_POST['admin_pass']; 
        $admin_no=$_POST['admin_no'];   
      
       
        $sql="INSERT INTO admin_login  (admin_uname,admin_name,admin_pass,admin_no) VALUES('$admin_uname','$admin_name','$admin_pass','$admin_no')";
       $_SESSION['admin_name']=$admin_name;
       $_SESSION['admin_pass']=$admin_pass;
        $_SESSION['success']="you are logged in";
      //header('location:Admin_login.php');
        if($conn->query($sql))
         {
          echo "New record is inserted successfully";
         }
         else
          echo "Error ".$sql. "<br>" . $conn->error;

      
    }  

      
    ?>  
