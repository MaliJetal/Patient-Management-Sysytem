<!DOCTYPE html>
<html>
<head>
	<title>PMS</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<style type="text/css">
    .jumbotron{
                color:#039BE5;
                float:left;
                margin-top: 15px;
                margin-left: 15px;
                margin-right:15px;
                width:50%;
    }
    .jumbotron-fluid{
                color:#039BE5;
                float:left;
                margin-top: 100px;
                margin-left: 15px;
    }
    .log{
      float:right;
    }
    .container1{
    width:100%;
    height: 300px;
    text-align: center;
    margin:0 auto;
    background-color: rgba(44, 62, 80,0.7);
    border-radius: 4px;
    margin-top: 100px;
    margin-bottom: 15px;
    margin-right: 50px;

  }
  .container1 img{
    width:120px;
    height:120px;
    margin-top:-60px;
    margin-bottom: 30px;
  }
  input[type="text"],input[type="password"]{
    width:300px;
    height: 45px;
    font-size:1em;
    margin-bottom: 20px;
    background-color: #fff;
    padding-left:35px;
    border-radius: 4px;
    border:none;
  }
.btn-login{
  padding:15px 30px;
  cursor: pointer;
  color:#fff;
  border:none;
  border-radius: 4px;
  background-color:#2c3e50;
  border-bottom: 4px solid #3F51B5;
  margin-bottom: 20px;
}
a{
  color:#fff;
}
  </style>
</head>
 <?php
       include_once 'header.php';

        ?>
<body>
          <div class="jumbotron">
        <h1 class="display-4"> WE CARE!</h1>
          <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
          <hr class="my-4">
          <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
          <p class="lead">
          <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
          </p>
          </div>
      <!-- slider-->
<!-- <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="slide1.png" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="slide2.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="slide3.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>  -->
	<div>
    <div class="jumbotron jumbotron-fluid">
           <div class="container">
              <h1 class="display-4">Fluid jumbotron</h1>
             <p class="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
           </div>
          </div>

          <!-- login form -->
      <div class="log">
        <div class="container1">
              <img src="team.png">
           <form action="./logindb.php" method="POST" class="form-box">
        
                <div class="form-input">
                  <input type="text" name="username" placeholder="Enter Username" required>
                </div>
                <div class="form-input">
                  <input type="password" name="password" placeholder="Enter Password" required>
                </div>
        
                <input type="submit" name="loginSubmit" value="Login" class="btn-login"><br>    
          </form>
        </div>
      </div>
  </div>	
  
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>